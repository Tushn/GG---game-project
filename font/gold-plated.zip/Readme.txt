Gold Plated Font

The Gold Plated font is a serif swash font based on Linux Libertine. Like all other JLH Fonts, this font is in the public domain and it comes with the Euro sign. Check out our other fonts, such as:

- Hand Drawn Shapes
- At Sign
- Grunge Handwriting
- Portmanteau
- Pretzel
- Chalk Line
- Seattle Avenue
- Tally Mark (symbol font)